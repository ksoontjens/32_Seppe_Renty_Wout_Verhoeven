/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hellotvxlet;

/**
 *
 * @author student
 */
public interface ObserverInterface {
    
    public abstract void update(int tijd);
    
    
}
